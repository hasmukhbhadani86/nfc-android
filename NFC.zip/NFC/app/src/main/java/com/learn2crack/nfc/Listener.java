package com.learn2crack.nfc;

public interface Listener {

    void onDialogDisplayed();

    void onDialogDismissed();
}
